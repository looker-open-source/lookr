library(testthat)
library(ini)

test_check("ini")
