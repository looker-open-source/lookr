# configr v0.3.2.1

- Support to write and convert json/ini/yaml to TOML format (Require python and python toml package)
