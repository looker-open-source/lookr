#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 24) | (28 << 16) | (0 << 8) | 8)
#define CMARK_VERSION_STRING "0.28.0.gfm.8"
#define CMARK_GFM_VERSION 8

#endif
