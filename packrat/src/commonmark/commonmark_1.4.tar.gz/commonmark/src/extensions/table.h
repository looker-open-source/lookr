#ifndef TABLE_H
#define TABLE_H

#include "core-extensions.h"

cmark_syntax_extension *create_table_extension(void);

#endif
