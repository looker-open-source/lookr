
print(RcppTOML::tomlparse("arrays.toml"))
