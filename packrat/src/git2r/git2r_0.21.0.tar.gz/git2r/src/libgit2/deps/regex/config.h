#ifndef _REGEX_CONFIG_H_
#define _REGEX_CONFIG_H_

# define GAWK
# define NO_MBSUPPORT

#endif
